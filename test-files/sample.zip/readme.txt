This is a test ZIP file.

Contains multiple files.